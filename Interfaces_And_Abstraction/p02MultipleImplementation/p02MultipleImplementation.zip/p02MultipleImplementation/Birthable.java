package p02MultipleImplementation;

public interface Birthable {
    String getBirthDate();
}
