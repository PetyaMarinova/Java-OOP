package p02MultipleImplementation;

public interface Identifiable {
    String getId();
}
