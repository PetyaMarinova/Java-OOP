package p04FoodShortage;

public interface Identifiable {
    String getId();
}
