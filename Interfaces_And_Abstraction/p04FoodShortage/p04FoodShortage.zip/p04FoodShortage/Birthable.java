package p04FoodShortage;

public interface Birthable {
    String getBirthDate();
}
