package p04FoodShortage;

public interface Person {
    String getName();
    int getAge();
}
