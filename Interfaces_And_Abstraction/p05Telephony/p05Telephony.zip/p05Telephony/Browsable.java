package p05Telephony;

public interface Browsable {
    String browse();
}
