package p05Telephony;

public interface Callable {
    String call();
}
