package p03BirthdayCelebrations;

public interface Birthable {
    String getBirthDate();
}
