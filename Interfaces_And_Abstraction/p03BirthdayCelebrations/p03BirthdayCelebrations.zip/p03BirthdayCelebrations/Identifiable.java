package p03BirthdayCelebrations;

public interface Identifiable {
    String getId();
}
