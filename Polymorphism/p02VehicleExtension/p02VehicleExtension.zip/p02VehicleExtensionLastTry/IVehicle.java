package p02VehicleExtensionLastTry;

public interface IVehicle {
    String drive(double kilometers);
    void refuel(double liters);
}
