package p01Vehicles;

public interface Vehicle {
    public abstract String driving(double distance);
    public abstract void refueling(double liters);
}
