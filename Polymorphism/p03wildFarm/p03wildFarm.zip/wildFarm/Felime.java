package wildFarm;

public abstract class Felime extends Mammal {
    protected Felime(String animalType, String animalName, double animalWeight, String livingRegion) {
        super(animalType, animalName, animalWeight, livingRegion);
    }
}
