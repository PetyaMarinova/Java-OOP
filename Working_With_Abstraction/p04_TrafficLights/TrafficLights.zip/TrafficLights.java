package TrafficLights;

public enum TrafficLights {
    GREEN,
    YELLOW,
    RED;
}
