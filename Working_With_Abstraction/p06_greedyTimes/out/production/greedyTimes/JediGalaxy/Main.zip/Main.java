package JediGalaxy;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int[] matrixRowCol = readArray(scanner);
        int row = matrixRowCol[0];
        int col = matrixRowCol[1];

        int[][] matrix = new int[row][col];
        fillMatrix(row, col, matrix);

        String command = scanner.nextLine();
        long sum = 0;
        while (!command.equals("Let the Force be with you")) {
            int[] coordinatesIvo = readArray(scanner);
            int[] coordinatesEvil = readArray(scanner);
            int rowEvil = coordinatesEvil[0];
            int colEvil = coordinatesEvil[1];

            while (rowEvil >= 0 && colEvil >= 0) {
                if (!isOutOfBounds(rowEvil, colEvil, matrix)) {
                    matrix[rowEvil][colEvil] = 0;
                }
                rowEvil--;
                colEvil--;
            }

            int rowIvo = coordinatesIvo[0];
            int colIvo = coordinatesIvo[1];

            while (rowIvo >= 0 && colIvo < matrix[1].length) {
                if (isOutOfBounds(rowIvo, colIvo, matrix)) {
                    sum += matrix[rowIvo][colIvo];
                }
                colIvo++;
                rowIvo--;
            }
            command = scanner.nextLine();
        }
        System.out.println(sum);
    }

    private static boolean isOutOfBounds(int rowEvil, int colEvil, int[][] matrix) {
        boolean isOut = true;
        if (rowEvil >= 0 && rowEvil < matrix.length && colEvil >= 0 && colEvil < matrix[rowEvil].length) {
            isOut = false;
        }
        return isOut;
    }

    private static void fillMatrix(int row, int col, int[][] matrix) {
        int startValue = 0;
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                matrix[i][j] = startValue++;
            }
        }
    }

    private static int[] readArray(Scanner scanner) {
        return Arrays.stream(scanner.nextLine().split("\\s++")).mapToInt(Integer::parseInt).toArray();
    }
}
