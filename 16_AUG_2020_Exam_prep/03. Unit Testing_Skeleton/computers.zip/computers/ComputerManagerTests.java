package computers;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ComputerManagerTests {
    private ComputerManager computerManager;

    @Before
    public void setUp() {
        this.computerManager = new ComputerManager();
    }

    @Test
    public void testCreatingConstructor() {
        this.computerManager = new ComputerManager();;
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testGetComputersReturnsUnmodifiableList() {
        this.computerManager.getComputers().remove(0);
    }

    @Test
    public void testGetComputersReturnsCorrectComputers(){
        Computer computer1 = new Computer("First", "Assos", 150.50);
        Computer computer2 = new Computer("Second", "Lenovo", 200.50);

        this.computerManager.addComputer(computer1);
        this.computerManager.addComputer(computer2);
        List<Computer> computersAdded = computerManager.getComputersByManufacturer(computer1.getManufacturer());
        Assert.assertNotNull(computersAdded);
        Assert.assertEquals(computersAdded.get(0).getManufacturer(),
                computer1.getManufacturer());

    }

    @Test
    public void testGetByManufacturerReturnsEmptyList(){
        Computer computer1 = new Computer("First", "Assos", 150.50);
        List<Computer> list = computerManager.getComputersByManufacturer(computer1.getManufacturer());
        Assert.assertNotNull(list);
        Assert.assertTrue(list.isEmpty());
    }

    @Test
    public void testGetCount(){
        List<Computer> computersAdded = createFakeListWithComputers();
        Assert.assertEquals(computersAdded.size(), this.computerManager.getCount());
    }

    @Test
    public void testZeroComputersInEmptyComputerManager(){
        Assert.assertEquals(0,this.computerManager.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddComputerWithNullValueThrowsException(){
        Computer computer = null;
        this.computerManager.addComputer(computer);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddComputerWillNotAddComputerIfItAlreadyExist(){
        Computer computer1 = new Computer("First", "Assos", 150.50);
        Computer computer2 = new Computer("Second", "Lenovo", 200.50);
        this.computerManager.addComputer(computer1);
        this.computerManager.addComputer(computer2);
        this.computerManager.addComputer(computer2);
    }

    @Test
    public void testAddComputerWillAddCorrectComputer(){
        Computer computer1 = new Computer("First", "Assos", 150.50);
        Computer computer2 = new Computer("Second", "Lenovo", 200.50);
        this.computerManager.addComputer(computer1);
        this.computerManager.addComputer(computer2);
        Assert.assertEquals(computer1,this.computerManager.getComputer("First","Assos"));
        Assert.assertEquals(computer2,this.computerManager.getComputer("Second","Lenovo"));
        Assert.assertEquals(2,this.computerManager.getComputers().size());
    }

    @Test
    public void testRemoveComputerIfItExists(){
        Computer computer1 = new Computer("First", "Assos", 150.50);
        this.computerManager.addComputer(computer1);
        Assert.assertEquals(0,this.computerManager.getCount());
        Assert.assertEquals(computer1, this.computerManager.removeComputer("First","Assos"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemovedComputerWillThrowExceptionIfItIsNotInTheManager(){
        Computer computer1 = new Computer("First", "Assos", 150.50);
        this.computerManager.addComputer(computer1);
        this.computerManager.removeComputer("Second", "Lenovo");
    }

    @Test()
    public void testRemovedComputerWillReturnCorrectComputer(){
        Computer computer1 = new Computer("First", "Assos", 150.50);
        Computer computer2 = new Computer("Second", "HP", 150.50);
        this.computerManager.addComputer(computer1);
        this.computerManager.addComputer(computer2);
        Computer removedComputer = this.computerManager.removeComputer("First", "Assos");
        Assert.assertEquals(computer1, removedComputer);
    }

    @Test (expected = IllegalArgumentException.class)
    public void testGetComputersByManufacturerWillThrowExceptionIfItIsNull(){
      Computer computer = new Computer("First", "Lenovo", 12.2);
      this.computerManager.addComputer(computer);
      this.computerManager.getComputersByManufacturer(null);
    }

    @Test (expected = IllegalArgumentException.class)
    public void testGetComputerWillThrowExceptionIfManufacturerIsNull(){
        createFakeListWithComputers();
        this.computerManager.getComputer(null, "Assos");
    }

    @Test (expected = IllegalArgumentException.class)
    public void testGetComputerWillThrowExceptionIfModelIsNull(){
        createFakeListWithComputers();
        this.computerManager.getComputer("First", null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGetComputerWillReturnNullIfItDoesNotExistInComputerManager(){
        createFakeListWithComputers();
        this.computerManager.getComputer("Third", "Assos");
    }

    @Test
    public void testGetComputerWillReturnCorrectComputer(){
        Computer computer1 = new Computer("First", "Assos", 150.50);
        Computer computer2 = new Computer("Second", "Lenovo", 200.50);
        this.computerManager.addComputer(computer1);
        this.computerManager.addComputer(computer2);
        Computer computerWeSearch = this.computerManager.getComputer("First", "Assos");
        Assert.assertNotNull(computerWeSearch);
        Assert.assertEquals(computer1.getManufacturer(), computerWeSearch.getManufacturer());
        Assert.assertEquals(computer1.getModel(), computerWeSearch.getModel());
    }

    @Test
    public void testGetComputersByManufacturerReturnsCorrectComputerList(){
        List<Computer> addedComputers = createFakeListWithComputers();
        List<Computer> filteredListByManufacturer = addedComputers.stream().filter(c -> c.getManufacturer().equals("First")).collect(Collectors.toList());
        Assert.assertEquals(filteredListByManufacturer,this.computerManager.getComputersByManufacturer("First"));
    }

    public List<Computer> createFakeListWithComputers(){
        Computer computer1 = new Computer("First", "Assos", 150.50);
        Computer computer2 = new Computer("Second", "Lenovo", 200.50);
        List<Computer> computersAdded = new ArrayList<>();
        computersAdded.add(computer1);
        computersAdded.add(computer2);
        this.computerManager.addComputer(computer1);
        this.computerManager.addComputer(computer2);
        return computersAdded;
    }
}