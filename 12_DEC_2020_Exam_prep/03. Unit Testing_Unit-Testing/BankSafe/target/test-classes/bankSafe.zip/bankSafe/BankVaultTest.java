package bankSafe;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.naming.OperationNotSupportedException;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;

public class BankVaultTest {
    private BankVault bankVault;
    private Item item1;
    private Item item2;

    @Before
    public void setUp() throws OperationNotSupportedException {
        this.bankVault = new BankVault();
        item1 = new Item("Peter", "123");
        item2 = new Item("Ivan", "456");
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testGetVaultCellsUnmodifiable() {
        Map<String, Item> allVaults = this.bankVault.getVaultCells();
        allVaults.values().forEach(Assert::assertNull);
        allVaults.put("A1",new Item("new owner", "new Id"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddItemThrowsExceptionIfThisMapDoNotHaveSuchCell() throws OperationNotSupportedException {
        this.bankVault.addItem("UnExistingCell", item1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testVaultCellNotEqualToNull() throws OperationNotSupportedException {
        this.bankVault.addItem("A1", item1);
        this.bankVault.addItem("A1", item2);
    }

    @Test(expected = OperationNotSupportedException.class)
    public void testItemAlreadyExistInTheBankVault() throws OperationNotSupportedException {
        this.bankVault.addItem("A1", item1);
        this.bankVault.addItem("A2", item2);
        this.bankVault.addItem("A3", item2);
    }

    @Test
    public void testAddCellAndItemCorrectly() throws OperationNotSupportedException {
        String message = this.bankVault.addItem("A1", item1);
        assertEquals(this.bankVault.getVaultCells().get("A1").getItemId(),item1.getItemId());
        assertEquals(this.bankVault.getVaultCells().get("A1").getOwner(),item1.getOwner());
        assertEquals("Item:" + item1.getItemId() + " saved successfully!",message);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemoveItemThrowsExceptionIfCellDoesNotExist() throws OperationNotSupportedException {
        this.bankVault.removeItem("UnExistingCell", item2);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemoveItemThrowsExceptionIfItemInThatCellDoesNotExist() throws OperationNotSupportedException {
        this.bankVault.addItem("A1", item1);
        this.bankVault.addItem("A2", item2);
        this.bankVault.removeItem("A1", item2);
    }

    @Test
    public void testRemoveItemFromSpecificCellCorrectly() throws OperationNotSupportedException {
        this.bankVault.addItem("A1", item1);
        this.bankVault.addItem("A2", item2);
        String message = this.bankVault.removeItem("A1", item1);
        Assert.assertNull(this.bankVault.getVaultCells().get("A1"));
        assertEquals("Remove item:" + item1.getItemId() + " successfully!",message);
    }


}